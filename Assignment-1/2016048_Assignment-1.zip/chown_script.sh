chmod u+s create_dir
chmod u+s fget
chmod u+s fput
chmod u+s ls
chmod u+s do_exec
chmod u+s getacl
chmod u+s setacl

