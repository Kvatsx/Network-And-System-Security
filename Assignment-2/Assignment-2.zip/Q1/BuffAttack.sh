rm input
python Extra/CustomPayloadGenerator.py > input
./victim < input