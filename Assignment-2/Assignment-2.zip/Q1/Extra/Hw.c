// Kaustav Vats (2016048)
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char const *argv[]) {
    printf("Hello World\n");
    return 0;
}

