hex1 = int(input(), 16)
hex2 = int(intput(), 16)
print hex(hex1+hex2)